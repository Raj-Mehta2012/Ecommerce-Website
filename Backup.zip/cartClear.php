<?php
session_start();
unset($_SESSION["cart_item"]);
$_SESSION['cartValueCount'] = 0;
echo 0;
?>